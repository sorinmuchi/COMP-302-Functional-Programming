(* HOMEWORK 1 : COMP 302 Fall 2014 
   
   PLEASE NOTE:  

   * All code files must be submitted electronically
     BEFORE class on 18 Sep, 2014

  *  The submitted file name must be hw1.ml 

  *  Your program must type-check and run usig 
     OCaml of at least OCaml 4.0

  * Remove all "raise NotImplemented" with your solutions
*)

exception NotImplemented
exception Domain

(* ------------------------------------------------------------*)
(* QUESTION 2 : WARM-UP                                        *)
(* ------------------------------------------------------------*)
(* Q2 Computing the square root                                *)

let square_root a =  
  let rec findroot x acc = 
    raise NotImplemented
  in
  findroot 1.0 epsilon_float


(* ------------------------------------------------------------*)
(* QUESTION 3 : House of Cards                                 *)
(* ------------------------------------------------------------*)

type suit = Clubs | Spades | Hearts | Diamonds

type rank =  Six | Seven | Eight | Nine | Ten | 
             Jack | Queen | King | Ace

type card = rank * suit

type hand = Empty | Hand of card * hand

(* dom : suit -> suit -> bool

   dom(s1,s2) = true iff suit s1 beats or is equal to suit s2
                relative to the ordering S > H > D > C         
   Invariants: none
   Effects: none
*)

let dom s1 s2 = match s1, s2 with
  | Spades, _        -> true
  | Hearts, Diamonds -> true
  | Hearts, Clubs    -> true
  | Diamonds, Clubs  -> true
  | s1, s2           -> s1 = s2


let dom_rank r1 r = raise NotImplemented

let greater (r1, s1) (r2, s2) = 
dom s1 s2 && dom_rank r1 r2

let rec insert c h = raise NotImplemented

let rec ins_sort h = raise NotImplemented

(* --------------------------------------------------------------------*)
(* QUESTION 3 Sparse representation of binary numbers                  *)
(* ------------------------------------------------------------------- *)

type nat = int list (* increasing list of weights, each a power of two *)

(* For example: 

5  = [1,4]
13 = [1,4,8]

*)

(* ------------------------------------------------------------------- *)
(* Q4.1 : Incrementing a binary number (10 points)                     *)
(* ------------------------------------------------------------------- *)

let inc ws = raise NotImplemented

(* ------------------------------------------------------------------- *)
(* Q4.2 : Decrementing a sparse binary number  (10 points)             *)
(* ------------------------------------------------------------------- *)

let dec ws = raise NotImplemented 

(* ------------------------------------------------------------------- *)
(* Q4.3 : Adding sparse binary numbers  (10 points)                    *)
(* ------------------------------------------------------------------- *)

let rec add m n  = raise NotImplemented 

(* ------------------------------------------------------------------- *)
(* Q4.3 : Converting to integer - tail recursively  (10 points)        *)
(* ------------------------------------------------------------------- *)
let sbinToInt n = raise NotImplemented
    
(* --------------------------------------------------------------------*)
(* QUESTION 5 Negation Normal Form                                     *)
(* ------------------------------------------------------------------- *)

type prop = 
  | Atom of string
  | Neg of prop
  | Conj of prop * prop
  | Disj of prop * prop
  | Impl of prop * prop


let rec nnf p = raise NotImplemented 

let f1 = Neg (Conj (Atom "p", Disj (Atom "q", Atom "r")))
let f2 = Neg (Conj (Neg (Atom "p"), Disj (Atom "q", Atom "r")))
